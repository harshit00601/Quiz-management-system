import csv
import random
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from datetime import datetime
import database
# -------------------- THEME --------------------
NAVY = "#0b1120"
SIDEBAR = "#101a2e"
PANEL = "#17243b"
PANEL_LIGHT = "#1d2e49"
BLUE = "#3b82f6"
BLUE_HOVER = "#2563eb"
CYAN = "#38bdf8"
WHITE = "#f1f5f9"
MUTED = "#9caec7"
GREEN = "#34d399"
RED = "#fb7185"
BORDER = "#2a3b55"
class QuizManagementSystem:
    def __init__(self, root):
        self.root = root
        self.root.title("QuizFlow | Quiz Management System")
        self.root.geometry("1180x760")
        self.root.minsize(950, 650)
        self.root.configure(bg=NAVY)
        database.initialize_database()
        self.student_name = ""
        self.questions = []
        self.answers = {}
        self.current_index = 0
        self.remaining_seconds = 120
        self.timer_job = None
        self.quiz_active = False
        self.last_score = 0
        self.last_total = 0
        self.last_percentage = 0.0
        self.configure_styles()
        self.build_shell()
        self.show_dashboard()
    def configure_styles(self):
        style = ttk.Style()
        style.theme_use("clam")
        style.configure(
            "Treeview",
            background=PANEL,
            fieldbackground=PANEL,
            foreground=WHITE,
            rowheight=32,
            borderwidth=0,
            font=("Segoe UI", 10)
        )
        style.configure(
            "Treeview.Heading",
            background=SIDEBAR,
            foreground=CYAN,
            font=("Segoe UI", 10, "bold"),
            relief="flat",
            padding=8
        )
        style.map(
            "Treeview",
            background=[("selected", BLUE)],
            foreground=[("selected", "white")]
        )
        style.configure(
            "TCombobox",
            fieldbackground=PANEL_LIGHT,
            background=PANEL_LIGHT,
            foreground=WHITE,
            arrowcolor=WHITE
        )
    def button(self, parent, text, command, primary=False, width=None):
        bg = BLUE if primary else PANEL_LIGHT
        active = BLUE_HOVER if primary else "#304563"
        return tk.Button(
            parent,
            text=text,
            command=command,
            bg=bg,
            fg=WHITE,
            activebackground=active,
            activeforeground=WHITE,
            font=("Segoe UI", 10, "bold"),
            relief="flat",
            bd=0,
            cursor="hand2",
            padx=15,
            pady=10,
            width=width
        )
    def label(self, parent, text, size=11, color=WHITE, bold=False, **kwargs):
        return tk.Label(
            parent,
            text=text,
            bg=kwargs.pop("bg", PANEL),
            fg=color,
            font=("Segoe UI", size, "bold" if bold else "normal"),
            **kwargs
        )
    def card(self, parent, padding=18):
        frame = tk.Frame(
            parent, bg=PANEL, padx=padding, pady=padding,
            highlightbackground=BORDER, highlightthickness=1
        )
        return frame
    def clear_content(self):
        if self.timer_job is not None and not self.quiz_active:
            try:
                self.root.after_cancel(self.timer_job)
            except tk.TclError:
                pass
            self.timer_job = None
        for widget in self.content.winfo_children():
            widget.destroy()
    def build_shell(self):
        self.sidebar = tk.Frame(self.root, bg=SIDEBAR, width=220)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)
        brand = tk.Frame(self.sidebar, bg=SIDEBAR)
        brand.pack(fill="x", padx=20, pady=(27, 32))
        tk.Label(
            brand, text="QF", bg=BLUE, fg="white",
            font=("Segoe UI", 18, "bold"), width=3, height=1
        ).pack(side="left", padx=(0, 10))
        tk.Label(
            brand, text="QuizFlow", bg=SIDEBAR, fg=WHITE,
            font=("Segoe UI", 18, "bold")
        ).pack(side="left")
        tk.Label(
            self.sidebar, text="WORKSPACE", bg=SIDEBAR, fg=MUTED,
            font=("Segoe UI", 9, "bold"), anchor="w"
        ).pack(fill="x", padx=22, pady=(0, 8))
        self.nav_buttons = {}
        nav_items = [
            ("Dashboard", self.show_dashboard),
            ("Take a Quiz", self.start_quiz_prompt),
            ("Performance", self.show_analytics),
            ("Admin Panel", self.admin_login),
        ]
        for text, command in nav_items:
            btn = tk.Button(
                self.sidebar,
                text="   " + text,
                command=command,
                anchor="w",
                bg=SIDEBAR,
                fg=MUTED,
                activebackground=PANEL_LIGHT,
                activeforeground=WHITE,
                font=("Segoe UI", 11),
                relief="flat",
                bd=0,
                cursor="hand2",
                padx=14,
                pady=13
            )
            btn.pack(fill="x", padx=10, pady=2)
            self.nav_buttons[text] = btn
        tk.Frame(self.sidebar, bg=BORDER, height=1).pack(
            fill="x", padx=18, pady=22
        )
        tk.Label(
            self.sidebar,
            text="PYTHON  •  TKINTER\nSQLITE DATABASE",
            bg=SIDEBAR,
            fg=MUTED,
            font=("Segoe UI", 9),
            justify="left"
        ).pack(side="bottom", anchor="w", padx=22, pady=22)
        main_area = tk.Frame(self.root, bg=NAVY)
        main_area.pack(side="left", fill="both", expand=True)
        self.topbar = tk.Frame(
            main_area, bg=NAVY, height=70,
            highlightbackground=BORDER, highlightthickness=0
        )
        self.topbar.pack(fill="x", padx=28, pady=(12, 0))
        self.topbar.pack_propagate(False)
        self.page_title = tk.Label(
            self.topbar, text="Dashboard",
            bg=NAVY, fg=WHITE, font=("Segoe UI", 20, "bold")
        )
        self.page_title.pack(side="left", anchor="center")
        self.top_status = tk.Label(
            self.topbar, text="●  SYSTEM READY",
            bg=NAVY, fg=GREEN, font=("Segoe UI", 9, "bold")
        )
        self.top_status.pack(side="right", anchor="center")
        self.content = tk.Frame(main_area, bg=NAVY)
        self.content.pack(fill="both", expand=True, padx=28, pady=18)
    def set_page(self, title, active=None):
        self.page_title.config(text=title)
        for name, btn in self.nav_buttons.items():
            if name == active:
                btn.config(bg=BLUE, fg=WHITE)
            else:
                btn.config(bg=SIDEBAR, fg=MUTED)
    def show_dashboard(self):
        if self.quiz_active:
            if not messagebox.askyesno(
                "Leave quiz", "Leave the current quiz? This attempt will not be saved."
            ):
                return
            self.quiz_active = False
        self.clear_content()
        self.set_page("Dashboard", "Dashboard")
        questions = database.get_questions()
        results = database.get_results()
        attempts = len(results)
        average = (
            sum(row[4] for row in results) / attempts if attempts else 0
        )
        best = max((row[4] for row in results), default=0)
        tk.Label(
            self.content, text="Welcome to QuizFlow",
            bg=NAVY, fg=WHITE, font=("Segoe UI", 24, "bold")
        ).pack(anchor="w")
        tk.Label(
            self.content,
            text="Your learning and assessment workspace.",
            bg=NAVY, fg=MUTED, font=("Segoe UI", 11)
        ).pack(anchor="w", pady=(3, 20))
        stats = tk.Frame(self.content, bg=NAVY)
        stats.pack(fill="x", pady=(0, 22))
        self.stat_card(stats, "TOTAL QUESTIONS", str(len(questions)), CYAN)
        self.stat_card(stats, "QUIZ ATTEMPTS", str(attempts), BLUE)
        self.stat_card(stats, "AVERAGE SCORE", f"{average:.1f}%", GREEN)
        self.stat_card(stats, "BEST SCORE", f"{best:.1f}%", "#c084fc")
        middle = tk.Frame(self.content, bg=NAVY)
        middle.pack(fill="both", expand=True)
        welcome = self.card(middle, 24)
        welcome.pack(side="left", fill="both", expand=True, padx=(0, 12))
        self.label(
            welcome, "Ready to challenge yourself?", 17, WHITE, True
        ).pack(anchor="w", pady=(0, 10))
        self.label(
            welcome,
            "Take a quiz, review your performance, and keep improving.",
            11, MUTED, wraplength=450, justify="left"
        ).pack(anchor="w", pady=(0, 20))
        self.button(
            welcome, "Start a Quiz  →", self.start_quiz_prompt, True
        ).pack(anchor="w")
        recent = self.card(middle, 18)
        recent.pack(side="left", fill="both", expand=True, padx=(12, 0))
        self.label(recent, "Recent Attempts", 15, WHITE, True).pack(anchor="w")
        if not results:
            self.label(
                recent, "No quiz attempts yet.\nYour results will appear here.",
                11, MUTED, justify="left"
            ).pack(anchor="w", pady=18)
        else:
            for row in results[:5]:
                line = tk.Frame(recent, bg=PANEL)
                line.pack(fill="x", pady=7)
                tk.Label(
                    line, text=row[1], bg=PANEL, fg=WHITE,
                    font=("Segoe UI", 10, "bold"), anchor="w"
                ).pack(side="left", fill="x", expand=True)
                tk.Label(
                    line, text=f"{row[4]:.1f}%",
                    bg=PANEL, fg=GREEN if row[4] >= 50 else RED,
                    font=("Segoe UI", 10, "bold")
                ).pack(side="right")
        tk.Label(
            self.content,
            text=f"Database connected  •  {len(questions)} questions available",
            bg=NAVY, fg=MUTED, font=("Segoe UI", 9)
        ).pack(anchor="w", pady=(15, 0))
        # DASHBOARD_GRAPHS_ADDED
        chart_area = tk.Frame(self.content, bg=NAVY)
        chart_area.pack(fill="both", expand=True, pady=(22, 8))
        score_card = self.card(chart_area, 18)
        score_card.pack(side="left", fill="both", expand=True, padx=(0, 10))
        latest_card = self.card(chart_area, 18)
        latest_card.pack(side="left", fill="both", expand=True, padx=(10, 0))
        self.label(
            score_card, "PERFORMANCE TREND", 13, WHITE, True
        ).pack(anchor="w", pady=(0, 3))
        self.label(
            score_card, "Your latest quiz attempts", 10, MUTED
        ).pack(anchor="w", pady=(0, 12))
        self.label(
            latest_card, "LATEST QUIZ SCORE", 13, WHITE, True
        ).pack(anchor="w", pady=(0, 3))
        self.label(
            latest_card, "Marks earned in your most recent attempt", 10, MUTED
        ).pack(anchor="w", pady=(0, 12))
        try:
            from matplotlib.figure import Figure
            from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
            from matplotlib.ticker import MultipleLocator
            chart_bg = PANEL
            text_color = "#aebed3"
            grid_color = "#34445d"
            blue_color = "#4387ff"
            cyan_color = "#32c5f4"
            green_color = "#25c997"
            # Performance trend: categorical labels prevent awkward decimal ticks.
            history = list(reversed(results[:10]))
            fig = Figure(figsize=(5.4, 3.0), dpi=100, facecolor=chart_bg)
            ax = fig.add_subplot(111)
            ax.set_facecolor(chart_bg)
            if history:
                labels = [f"Attempt {i + 1}" for i in range(len(history))]
                scores = [max(0, min(100, float(row[4]))) for row in history]
                ax.plot(
                    labels, scores,
                    color=cyan_color, linewidth=2.8,
                    marker="o", markersize=7,
                    markerfacecolor=blue_color,
                    markeredgecolor=chart_bg, markeredgewidth=1.5,
                    zorder=3
                )
                ax.fill_between(
                    range(len(scores)), scores, 0,
                    color=cyan_color, alpha=0.10
                )
                ax.set_ylim(0, 100)
                ax.set_yticks([0, 25, 50, 75, 100])
                ax.set_ylabel("Score (%)", color=text_color, labelpad=8)
                ax.set_xticks(range(len(labels)))
                ax.set_xticklabels(labels, rotation=0, ha="center")
                ax.grid(axis="y", color=grid_color, linewidth=0.8, alpha=0.8)
                ax.set_axisbelow(True)
                ax.tick_params(axis="both", colors=text_color, labelsize=8,
                               length=0, pad=7)
                ax.margins(x=0.12)
                for spine in ax.spines.values():
                    spine.set_visible(False)
                ax.spines["bottom"].set_visible(True)
                ax.spines["bottom"].set_color(grid_color)
            else:
                ax.text(
                    0.5, 0.53, "No quiz attempts yet",
                    color=WHITE, fontsize=12, fontweight="bold",
                    ha="center", va="center", transform=ax.transAxes
                )
                ax.text(
                    0.5, 0.42, "Complete a quiz to see your progress here.",
                    color=text_color, fontsize=9,
                    ha="center", va="center", transform=ax.transAxes
                )
                ax.set_axis_off()
            fig.subplots_adjust(left=0.13, right=0.97, top=0.96, bottom=0.19)
            canvas = FigureCanvasTkAgg(fig, master=score_card)
            canvas.draw()
            canvas.get_tk_widget().pack(fill="both", expand=True)
            # Latest score: donut chart with a clear percentage in the center.
            fig2 = Figure(figsize=(4.3, 3.0), dpi=100, facecolor=chart_bg)
            ax2 = fig2.add_subplot(111)
            ax2.set_facecolor(chart_bg)
            if results:
                latest = results[0]
                score = max(0, float(latest[2]))
                total = max(0, float(latest[3]))
                percentage = max(0, min(100, float(latest[4])))
                if total > 0:
                    ax2.pie(
                        [percentage, 100 - percentage],
                        colors=[green_color, grid_color],
                        startangle=90, counterclock=False,
                        wedgeprops={"width": 0.22, "edgecolor": chart_bg,
                                    "linewidth": 3}
                    )
                    ax2.text(
                        0, 0.08, f"{percentage:.0f}%",
                        ha="center", va="center",
                        color=WHITE, fontsize=23, fontweight="bold"
                    )
                    ax2.text(
                        0, -0.20, "SCORE",
                        ha="center", va="center",
                        color=text_color, fontsize=9
                    )
                    ax2.text(
                        0, -1.20, f"{score:g} of {total:g} marks",
                        ha="center", va="center",
                        color=text_color, fontsize=10
                    )
                    ax2.set_aspect("equal")
                    ax2.set_xlim(-1.35, 1.35)
                    ax2.set_ylim(-1.35, 1.25)
                    ax2.set_axis_off()
                else:
                    ax2.text(
                        0.5, 0.5, "No marks available",
                        color=text_color, ha="center", va="center",
                        transform=ax2.transAxes
                    )
                    ax2.set_axis_off()
            else:
                ax2.text(
                    0.5, 0.53, "No score to display yet",
                    color=WHITE, fontsize=11, fontweight="bold",
                    ha="center", va="center", transform=ax2.transAxes
                )
                ax2.text(
                    0.5, 0.42, "Your first result will appear here.",
                    color=text_color, fontsize=9,
                    ha="center", va="center", transform=ax2.transAxes
                )
                ax2.set_axis_off()
            fig2.subplots_adjust(left=0.08, right=0.92, top=0.96, bottom=0.08)
            canvas2 = FigureCanvasTkAgg(fig2, master=latest_card)
            canvas2.draw()
            canvas2.get_tk_widget().pack(fill="both", expand=True)
        except Exception as exc:
            self.label(
                score_card, f"Could not display charts: {exc}", 10, MUTED
            ).pack(anchor="w")
    def stat_card(self, parent, title, value, accent):
        frame = tk.Frame(
            parent, bg=PANEL, padx=17, pady=17,
            highlightbackground=BORDER, highlightthickness=1
        )
        frame.pack(side="left", fill="both", expand=True, padx=(0, 10))
        tk.Frame(frame, bg=accent, height=4).pack(fill="x", pady=(0, 13))
        tk.Label(
            frame, text=title, bg=PANEL, fg=MUTED,
            font=("Segoe UI", 9, "bold")
        ).pack(anchor="w")
        tk.Label(
            frame, text=value, bg=PANEL, fg=WHITE,
            font=("Segoe UI", 24, "bold")
        ).pack(anchor="w", pady=(5, 0))
    def start_quiz_prompt(self):
        if self.quiz_active:
            messagebox.showinfo("Quiz in progress", "Finish the current quiz first.")
            return
        dialog = tk.Toplevel(self.root)
        dialog.title("Start Quiz")
        dialog.geometry("390x260")
        dialog.configure(bg=PANEL)
        dialog.resizable(False, False)
        dialog.transient(self.root)
        dialog.grab_set()
        tk.Label(
            dialog, text="Let's begin!",
            bg=PANEL, fg=WHITE, font=("Segoe UI", 20, "bold")
        ).pack(pady=(25, 8))
        tk.Label(
            dialog, text="Enter your name to start the quiz",
            bg=PANEL, fg=MUTED, font=("Segoe UI", 10)
        ).pack()
        name_entry = tk.Entry(
            dialog, bg=PANEL_LIGHT, fg=WHITE, insertbackground=WHITE,
            relief="flat", font=("Segoe UI", 12), width=30
        )
        name_entry.pack(pady=18, ipady=8)
        name_entry.focus_set()
        def begin():
            name = name_entry.get().strip()
            if not name:
                messagebox.showwarning(
                    "Name required", "Please enter your name.", parent=dialog
                )
                return
            dialog.destroy()
            self.begin_quiz(name)
        self.button(dialog, "Start Quiz", begin, True).pack()
        name_entry.bind("<Return>", lambda event: begin())
    def begin_quiz(self, name):
        questions = list(database.get_questions())
        if not questions:
            messagebox.showerror("No questions", "Ask the admin to add questions.")
            return
        random.shuffle(questions)
        self.questions = questions
        self.student_name = name
        self.answers = {}
        self.current_index = 0
        self.remaining_seconds = 120
        self.quiz_active = True
        self.show_question()
        self.update_timer()
    def show_question(self):
        self.clear_content()
        self.set_page("Quiz in Progress", "Take a Quiz")
        row = self.questions[self.current_index]
        question_id, question, a, b, c, d, correct, marks = row
        head = tk.Frame(self.content, bg=NAVY)
        head.pack(fill="x", pady=(0, 15))
        tk.Label(
            head, text=f"Hello, {self.student_name}",
            bg=NAVY, fg=WHITE, font=("Segoe UI", 15, "bold")
        ).pack(side="left")
        self.timer_label = tk.Label(
            head, text="02:00", bg=NAVY, fg=CYAN,
            font=("Segoe UI", 16, "bold")
        )
        self.timer_label.pack(side="right")
        progress_area = tk.Frame(self.content, bg=NAVY)
        progress_area.pack(fill="x", pady=(0, 20))
        tk.Label(
            progress_area,
            text=f"QUESTION {self.current_index + 1} OF {len(self.questions)}",
            bg=NAVY, fg=MUTED, font=("Segoe UI", 9, "bold")
        ).pack(anchor="w", pady=(0, 7))
        progress = ttk.Progressbar(
            progress_area, maximum=len(self.questions),
            value=self.current_index + 1, length=400
        )
        progress.pack(fill="x")
        card = self.card(self.content, 28)
        card.pack(fill="both", expand=True)
        tk.Label(
            card, text=f"Question {self.current_index + 1}",
            bg=PANEL, fg=CYAN, font=("Segoe UI", 10, "bold")
        ).pack(anchor="w", pady=(0, 12))
        tk.Label(
            card, text=question, bg=PANEL, fg=WHITE,
            font=("Segoe UI", 17, "bold"), wraplength=780,
            justify="left"
        ).pack(anchor="w", pady=(0, 22))
        self.answer_var = tk.StringVar(
            master=self.root,
            value=self.answers.get(question_id, "")
        )
        for letter, option in zip("ABCD", [a, b, c, d]):
            rb = tk.Radiobutton(
                card,
                text=f"{letter}.   {option}",
                variable=self.answer_var,
                value=letter,
                indicatoron=True,
                tristatevalue="__none__",
                bg=PANEL,
                fg=WHITE,
                selectcolor=PANEL,
                activebackground=PANEL,
                activeforeground=CYAN,
                disabledforeground=MUTED,
                font=("Segoe UI", 12),
                anchor="w",
                padx=12,
                pady=8,
                cursor="hand2"
            )
            rb.pack(fill="x", anchor="w", pady=3)
        bottom = tk.Frame(self.content, bg=NAVY)
        bottom.pack(fill="x", pady=(16, 0))
        self.button(
            bottom, "← Previous", self.previous_question,
        ).pack(side="left")
        if self.current_index < len(self.questions) - 1:
            self.button(
                bottom, "Next →", self.next_question, True
            ).pack(side="right")
        else:
            self.button(
                bottom, "Submit Quiz", self.submit_quiz, True
            ).pack(side="right")
        tk.Label(
            bottom, text="Select one answer for each question",
            bg=NAVY, fg=MUTED, font=("Segoe UI", 9)
        ).pack(side="left", padx=20)
    def remember_answer(self):
        row = self.questions[self.current_index]
        self.answers[row[0]] = self.answer_var.get()
    def next_question(self):
        self.remember_answer()
        if self.current_index < len(self.questions) - 1:
            self.current_index += 1
            self.show_question()
    def previous_question(self):
        self.remember_answer()
        if self.current_index > 0:
            self.current_index -= 1
            self.show_question()
    def update_timer(self):
        if not self.quiz_active:
            return
        mins, secs = divmod(self.remaining_seconds, 60)
        if hasattr(self, "timer_label") and self.timer_label.winfo_exists():
            self.timer_label.config(text=f"{mins:02d}:{secs:02d}")
        if self.remaining_seconds <= 0:
            self.timer_job = None
            messagebox.showinfo("Time is up", "Your quiz will be submitted now.")
            self.submit_quiz(confirm=False)
            return
        self.remaining_seconds -= 1
        self.timer_job = self.root.after(1000, self.update_timer)
    def submit_quiz(self, confirm=True):
        if not self.quiz_active:
            return
        self.remember_answer()
        if confirm and not messagebox.askyesno(
            "Submit Quiz", "Are you sure you want to submit your answers?"
        ):
            return
        if self.timer_job is not None:
            try:
                self.root.after_cancel(self.timer_job)
            except tk.TclError:
                pass
            self.timer_job = None
        score = sum(
            row[7] for row in self.questions
            if self.answers.get(row[0]) == row[6]
        )
        total = sum(row[7] for row in self.questions)
        percentage = score / total * 100 if total else 0
        database.save_result(self.student_name, score, total, percentage)
        self.last_score = score
        self.last_total = total
        self.last_percentage = percentage
        self.quiz_active = False
        self.show_result()
    def show_result(self):
        self.clear_content()
        self.set_page("Quiz Result")
        tk.Label(
            self.content, text="QUIZ COMPLETED",
            bg=NAVY, fg=CYAN, font=("Segoe UI", 12, "bold")
        ).pack(pady=(18, 6))
        tk.Label(
            self.content, text=f"Well done, {self.student_name}!",
            bg=NAVY, fg=WHITE, font=("Segoe UI", 25, "bold")
        ).pack(pady=(0, 20))
        result_card = self.card(self.content, 30)
        result_card.pack(fill="x", padx=45, pady=5)
        tk.Label(
            result_card, text=f"{self.last_percentage:.1f}%",
            bg=PANEL, fg=GREEN if self.last_percentage >= 50 else RED,
            font=("Segoe UI", 38, "bold")
        ).pack(pady=(0, 5))
        tk.Label(
            result_card, text=f"Score: {self.last_score} / {self.last_total}",
            bg=PANEL, fg=WHITE, font=("Segoe UI", 15, "bold")
        ).pack(pady=5)
        tk.Label(
            result_card,
            text="Excellent work!" if self.last_percentage >= 80
            else "Good effort!" if self.last_percentage >= 50
            else "Keep practising. You can improve!",
            bg=PANEL, fg=MUTED, font=("Segoe UI", 11)
        ).pack(pady=5)
        actions = tk.Frame(self.content, bg=NAVY)
        actions.pack(pady=18)
        self.button(
            actions, "Review Answers", self.review_answers
        ).pack(side="left", padx=5)
        self.button(
            actions, "Back to Dashboard", self.show_dashboard, True
        ).pack(side="left", padx=5)
        self.button(
            actions, "Try Again", self.start_quiz_prompt
        ).pack(side="left", padx=5)
    def review_answers(self):
        window = tk.Toplevel(self.root)
        window.title("Answer Review")
        window.geometry("800x600")
        window.configure(bg=NAVY)
        tk.Label(
            window, text="Answer Review", bg=NAVY, fg=WHITE,
            font=("Segoe UI", 20, "bold")
        ).pack(anchor="w", padx=20, pady=18)
        text = tk.Text(
            window, bg=PANEL, fg=WHITE, insertbackground=WHITE,
            font=("Segoe UI", 11), wrap="word", padx=15, pady=12,
            relief="flat"
        )
        text.pack(fill="both", expand=True, padx=20, pady=(0, 20))
        for number, row in enumerate(self.questions, 1):
            qid, question, a, b, c, d, correct, marks = row
            options = {"A": a, "B": b, "C": c, "D": d}
            selected = self.answers.get(qid, "")
            text.insert("end", f"{number}. {question}\n")
            text.insert(
                "end",
                f"Your answer: {selected + '. ' + options[selected] if selected in options else 'Not answered'}\n"
            )
            text.insert("end", f"Correct answer: {correct}. {options[correct]}\n\n")
        text.config(state="disabled")
    def admin_login(self):
        if self.quiz_active:
            messagebox.showinfo("Quiz in progress", "Finish the current quiz first.")
            return
        dialog = tk.Toplevel(self.root)
        dialog.title("Admin Login")
        dialog.geometry("390x340")
        dialog.configure(bg=PANEL)
        dialog.resizable(False, False)
        dialog.transient(self.root)
        dialog.grab_set()
        tk.Label(
            dialog, text="ADMIN ACCESS", bg=PANEL, fg=CYAN,
            font=("Segoe UI", 11, "bold")
        ).pack(pady=(25, 5))
        tk.Label(
            dialog, text="Sign in to manage QuizFlow",
            bg=PANEL, fg=WHITE, font=("Segoe UI", 17, "bold")
        ).pack(pady=(0, 18))
        tk.Label(
            dialog, text="Username", bg=PANEL, fg=MUTED
        ).pack(anchor="w", padx=35)
        username = tk.Entry(
            dialog, bg=PANEL_LIGHT, fg=WHITE, insertbackground=WHITE,
            relief="flat", font=("Segoe UI", 11)
        )
        username.pack(fill="x", padx=35, pady=(5, 12), ipady=7)
        tk.Label(
            dialog, text="Password", bg=PANEL, fg=MUTED
        ).pack(anchor="w", padx=35)
        password = tk.Entry(
            dialog, show="*", bg=PANEL_LIGHT, fg=WHITE,
            insertbackground=WHITE, relief="flat", font=("Segoe UI", 11)
        )
        password.pack(fill="x", padx=35, pady=(5, 18), ipady=7)
        def verify():
            if username.get().strip() == "admin" and password.get() == "admin123":
                dialog.destroy()
                self.show_admin()
            else:
                messagebox.showerror(
                    "Login failed", "Incorrect username or password.",
                    parent=dialog
                )
        self.button(dialog, "Sign In", verify, True).pack(fill="x", padx=35)
        password.bind("<Return>", lambda event: verify())
        username.focus_set()
    def show_admin(self):
        self.clear_content()
        self.set_page("Admin Panel", "Admin Panel")
        notebook = ttk.Notebook(self.content)
        notebook.pack(fill="both", expand=True)
        questions_tab = tk.Frame(notebook, bg=NAVY)
        results_tab = tk.Frame(notebook, bg=NAVY)
        notebook.add(questions_tab, text="  Question Management  ")
        notebook.add(results_tab, text="  Student Results  ")
        self.build_questions_tab(questions_tab)
        self.build_results_tab(results_tab)
    def build_questions_tab(self, parent):
        header = tk.Frame(parent, bg=NAVY)
        header.pack(fill="x", padx=14, pady=14)
        tk.Label(
            header, text="Manage Questions",
            bg=NAVY, fg=WHITE, font=("Segoe UI", 17, "bold")
        ).pack(side="left")
        self.question_search = tk.StringVar()
        search = tk.Entry(
            header, textvariable=self.question_search,
            bg=PANEL, fg=WHITE, insertbackground=WHITE,
            relief="flat", width=28, font=("Segoe UI", 10)
        )
        search.pack(side="right", ipady=7)
        search.insert(0, "")
        search.bind("<KeyRelease>", lambda event: self.refresh_questions())
        tk.Label(
            parent, text="Search questions by text or ID",
            bg=NAVY, fg=MUTED, font=("Segoe UI", 9)
        ).pack(anchor="e", padx=20, pady=(0, 5))
        columns = ("id", "question", "correct", "marks")
        self.question_tree = ttk.Treeview(
            parent, columns=columns, show="headings"
        )
        for col, title, width in [
            ("id", "ID", 55),
            ("question", "Question", 560),
            ("correct", "Answer", 100),
            ("marks", "Marks", 80)
        ]:
            self.question_tree.heading(col, text=title)
            self.question_tree.column(col, width=width, anchor="w")
        self.question_tree.pack(
            fill="both", expand=True, padx=14, pady=(0, 12)
        )
        actions = tk.Frame(parent, bg=NAVY)
        actions.pack(fill="x", padx=14, pady=(0, 14))
        self.button(
            actions, "+ Add Question", self.add_question_dialog, True
        ).pack(side="left", padx=(0, 8))
        self.button(
            actions, "Delete Selected", self.remove_question
        ).pack(side="left")
        self.refresh_questions()
    def refresh_questions(self):
        if not hasattr(self, "question_tree"):
            return
        for item in self.question_tree.get_children():
            self.question_tree.delete(item)
        search = self.question_search.get().strip().lower()
        for row in database.get_questions():
            if search and search not in str(row[0]).lower() and search not in row[1].lower():
                continue
            self.question_tree.insert(
                "", "end", values=(row[0], row[1], row[6], row[7])
            )
    def add_question_dialog(self):
        dialog = tk.Toplevel(self.root)
        dialog.title("Add Question")
        dialog.geometry("500x590")
        dialog.configure(bg=PANEL)
        dialog.transient(self.root)
        dialog.grab_set()
        tk.Label(
            dialog, text="Create a Question", bg=PANEL, fg=WHITE,
            font=("Segoe UI", 19, "bold")
        ).pack(pady=(18, 12))
        form = tk.Frame(dialog, bg=PANEL)
        form.pack(fill="both", expand=True, padx=25)
        def add_field(title):
            tk.Label(
                form, text=title, bg=PANEL, fg=MUTED,
                font=("Segoe UI", 10)
            ).pack(anchor="w", pady=(6, 3))
            entry = tk.Entry(
                form, bg=PANEL_LIGHT, fg=WHITE,
                insertbackground=WHITE, relief="flat",
                font=("Segoe UI", 11)
            )
            entry.pack(fill="x", ipady=6)
            return entry
        q = add_field("Question")
        a = add_field("Option A")
        b = add_field("Option B")
        c = add_field("Option C")
        d = add_field("Option D")
        tk.Label(
            form, text="Correct option", bg=PANEL, fg=MUTED
        ).pack(anchor="w", pady=(8, 3))
        correct = ttk.Combobox(
            form, values=["A", "B", "C", "D"], state="readonly"
        )
        correct.set("A")
        correct.pack(fill="x")
        tk.Label(
            form, text="Marks", bg=PANEL, fg=MUTED
        ).pack(anchor="w", pady=(8, 3))
        marks = tk.Entry(
            form, bg=PANEL_LIGHT, fg=WHITE,
            insertbackground=WHITE, relief="flat"
        )
        marks.insert(0, "1")
        marks.pack(fill="x", ipady=5)
        def save():
            values = [e.get().strip() for e in (q, a, b, c, d)]
            if not all(values):
                messagebox.showwarning(
                    "Missing fields", "Fill in the question and all options.",
                    parent=dialog
                )
                return
            try:
                points = int(marks.get())
                if points <= 0:
                    raise ValueError
            except ValueError:
                messagebox.showwarning(
                    "Invalid marks", "Enter a positive whole number.",
                    parent=dialog
                )
                return
            try:
                database.add_question(
                    values[0], values[1], values[2], values[3], values[4],
                    correct.get(), points
                )
            except Exception as error:
                messagebox.showerror(
                    "Database error", str(error), parent=dialog
                )
                return
            dialog.destroy()
            self.refresh_questions()
            messagebox.showinfo("Saved", "Question added successfully.")
        self.button(
            dialog, "Save Question", save, True
        ).pack(fill="x", padx=25, pady=15)
    def remove_question(self):
        selected = self.question_tree.selection()
        if not selected:
            messagebox.showwarning(
                "Select a question", "Select a question to delete."
            )
            return
        values = self.question_tree.item(selected[0], "values")
        question_id = int(values[0])
        if messagebox.askyesno(
            "Delete question",
            f"Delete question #{question_id}? This cannot be undone."
        ):
            database.delete_question(question_id)
            self.refresh_questions()
    def build_results_tab(self, parent):
        top = tk.Frame(parent, bg=NAVY)
        top.pack(fill="x", padx=14, pady=14)
        tk.Label(
            top, text="Student Performance",
            bg=NAVY, fg=WHITE, font=("Segoe UI", 17, "bold")
        ).pack(side="left")
        self.button(
            top, "Export CSV", self.export_results, True
        ).pack(side="right")
        columns = ("id", "name", "score", "total", "percentage", "date")
        self.results_tree = ttk.Treeview(
            parent, columns=columns, show="headings"
        )
        headings = {
            "id": ("ID", 45),
            "name": ("Student", 170),
            "score": ("Score", 75),
            "total": ("Total", 75),
            "percentage": ("Percentage", 105),
            "date": ("Date and Time", 180)
        }
        for col, (title, width) in headings.items():
            self.results_tree.heading(col, text=title)
            self.results_tree.column(col, width=width, anchor="center")
        self.results_tree.pack(
            fill="both", expand=True, padx=14, pady=(0, 10)
        )
        self.refresh_results()
    def refresh_results(self):
        if not hasattr(self, "results_tree"):
            return
        for item in self.results_tree.get_children():
            self.results_tree.delete(item)
        for row in database.get_results():
            self.results_tree.insert(
                "", "end",
                values=(
                    row[0], row[1], row[2], row[3],
                    f"{row[4]:.2f}%", row[5]
                )
            )
    def export_results(self):
        results = database.get_results()
        if not results:
            messagebox.showinfo("No results", "There are no results to export.")
            return
        path = filedialog.asksaveasfilename(
            title="Export student results",
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv")],
            initialfile="quiz_results.csv"
        )
        if not path:
            return
        try:
            with open(path, "w", newline="", encoding="utf-8-sig") as file:
                writer = csv.writer(file)
                writer.writerow([
                    "ID", "Student Name", "Score",
                    "Total Marks", "Percentage", "Date and Time"
                ])
                for row in results:
                    writer.writerow(row)
            messagebox.showinfo(
                "Export complete", f"Results exported successfully:\n{path}"
            )
        except OSError as error:
            messagebox.showerror("Export failed", str(error))
    def show_analytics(self):
        if self.quiz_active:
            messagebox.showinfo("Quiz in progress", "Finish the current quiz first.")
            return
        self.clear_content()
        self.set_page("Performance Analytics", "Performance")
        results = database.get_results()
        attempts = len(results)
        average = sum(r[4] for r in results) / attempts if attempts else 0
        best = max((r[4] for r in results), default=0)
        passed = sum(1 for r in results if r[4] >= 50)
        tk.Label(
            self.content, text="Performance Overview",
            bg=NAVY, fg=WHITE, font=("Segoe UI", 23, "bold")
        ).pack(anchor="w")
        tk.Label(
            self.content,
            text="Review saved quiz attempts and student score history.",
            bg=NAVY, fg=MUTED, font=("Segoe UI", 11)
        ).pack(anchor="w", pady=(5, 20))
        stats = tk.Frame(self.content, bg=NAVY)
        stats.pack(fill="x", pady=(0, 20))
        self.stat_card(stats, "TOTAL ATTEMPTS", str(attempts), CYAN)
        self.stat_card(stats, "AVERAGE SCORE", f"{average:.1f}%", BLUE)
        self.stat_card(stats, "BEST SCORE", f"{best:.1f}%", GREEN)
        self.stat_card(stats, "SCORES ≥ 50%", str(passed), "#c084fc")
        history = self.card(self.content, 18)
        history.pack(fill="both", expand=True)
        tk.Label(
            history, text="Score History",
            bg=PANEL, fg=WHITE, font=("Segoe UI", 15, "bold")
        ).pack(anchor="w", pady=(0, 12))
        if not results:
            tk.Label(
                history, text="No results recorded yet. Take a quiz to begin.",
                bg=PANEL, fg=MUTED, font=("Segoe UI", 11)
            ).pack(anchor="w", pady=12)
        else:
            columns = ("name", "score", "total", "percentage", "date")
            tree = ttk.Treeview(
                history, columns=columns, show="headings", height=9
            )
            headings = [
                ("name", "Student", 180),
                ("score", "Score", 90),
                ("total", "Total", 90),
                ("percentage", "Percentage", 120),
                ("date", "Date and Time", 200)
            ]
            for col, title, width in headings:
                tree.heading(col, text=title)
                tree.column(col, width=width, anchor="center")
            tree.pack(fill="both", expand=True)
            for row in results:
                tree.insert(
                    "", "end",
                    values=(
                        row[1], row[2], row[3],
                        f"{row[4]:.2f}%", row[5]
                    )
                )
        actions = tk.Frame(self.content, bg=NAVY)
        actions.pack(fill="x", pady=(15, 0))
        self.button(
            actions, "Refresh Analytics", self.show_analytics, True
        ).pack(side="left")
        self.button(
            actions, "Export Results to CSV", self.export_results
        ).pack(side="left", padx=10)
if __name__ == "__main__":
    root = tk.Tk()
    app = QuizManagementSystem(root)
    root.mainloop()

