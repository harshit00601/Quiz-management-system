﻿import sqlite3
from pathlib import Path
from datetime import datetime

DB_PATH = Path(__file__).resolve().parent / "quiz_management.db"


def get_connection():
    return sqlite3.connect(DB_PATH)


def initialize_database():
    with get_connection() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS questions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                question TEXT NOT NULL,
                option_a TEXT NOT NULL,
                option_b TEXT NOT NULL,
                option_c TEXT NOT NULL,
                option_d TEXT NOT NULL,
                correct_option TEXT NOT NULL CHECK(correct_option IN ('A', 'B', 'C', 'D')),
                marks INTEGER NOT NULL DEFAULT 1 CHECK(marks > 0)
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                student_name TEXT NOT NULL,
                score INTEGER NOT NULL,
                total_marks INTEGER NOT NULL,
                percentage REAL NOT NULL,
                taken_at TEXT NOT NULL,
                quiz_category TEXT NOT NULL DEFAULT 'Uncategorized',
                quiz_mode TEXT NOT NULL DEFAULT 'Legacy'
            )
        """)
        # Safely upgrade existing databases without deleting any saved results.
        columns = {row[1] for row in conn.execute("PRAGMA table_info(results)")}
        if "quiz_category" not in columns:
            conn.execute("ALTER TABLE results ADD COLUMN quiz_category TEXT NOT NULL DEFAULT 'Uncategorized'")
        if "quiz_mode" not in columns:
            conn.execute("ALTER TABLE results ADD COLUMN quiz_mode TEXT NOT NULL DEFAULT 'Legacy'")

        count = conn.execute("SELECT COUNT(*) FROM questions").fetchone()[0]
        if count == 0:
            questions = [
                ("Which keyword defines a function in Python?", "func", "define", "def", "function", "C", 1),
                ("Which data type stores True or False?", "int", "bool", "str", "list", "B", 1),
                ("Which function displays output in Python?", "input()", "print()", "show()", "display()", "B", 1),
                ("Which collection stores key-value pairs?", "List", "Tuple", "Dictionary", "Set", "C", 1),
                ("Which symbol starts a Python comment?", "//", "/*", "#", "<!--", "C", 1),
                ("What is the result of 3 ** 2?", "6", "9", "8", "5", "B", 1),
                ("Which method adds an item to a list?", "add()", "append()", "push()", "attach()", "B", 1),
                ("Which loop repeats while a condition is true?", "if", "switch", "while", "try", "C", 1),
                ("Which module supports SQLite in Python?", "sqlite3", "sql", "database", "dbconnect", "A", 1),
                ("Which keyword handles an exception?", "catch", "except", "error", "final", "B", 1),
            ]
            conn.executemany("""
                INSERT INTO questions (question, option_a, option_b, option_c, option_d, correct_option, marks)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, questions)


def get_questions():
    with get_connection() as conn:
        return conn.execute("""
            SELECT id, question, option_a, option_b, option_c, option_d, correct_option, marks
            FROM questions ORDER BY id
        """).fetchall()


def add_question(question, a, b, c, d, correct, marks):
    with get_connection() as conn:
        conn.execute("""
            INSERT INTO questions (question, option_a, option_b, option_c, option_d, correct_option, marks)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (question, a, b, c, d, correct, marks))


def delete_question(question_id):
    with get_connection() as conn:
        conn.execute("DELETE FROM questions WHERE id = ?", (question_id,))


def save_result(name, score, total, percentage, quiz_category="Uncategorized", quiz_mode="Legacy"):
    with get_connection() as conn:
        conn.execute("""
            INSERT INTO results (
                student_name, score, total_marks, percentage, taken_at, quiz_category, quiz_mode
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            name, score, total, percentage,
            datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            quiz_category, quiz_mode
        ))


def get_results():
    with get_connection() as conn:
        return conn.execute("""
            SELECT id, student_name, score, total_marks, percentage, taken_at, quiz_category, quiz_mode
            FROM results ORDER BY id DESC
        """).fetchall()


if __name__ == "__main__":
    initialize_database()
    print("Database initialized successfully!")
    print(f"Database location: {DB_PATH}")
    print(f"Questions available: {len(get_questions())}")
    print("Database module is ready!")
